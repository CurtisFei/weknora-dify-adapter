# WeKnora–Dify Adapter Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build a production-ready FastAPI service that implements Dify's external knowledge `/retrieval` contract by querying a WeKnora knowledge base.

**Architecture:** A FastAPI application validates Dify requests and Bearer credentials, maps them into vector-only WeKnora hybrid-search requests through an injected HTTPX client, then maps the upstream envelope into Dify records. Pure mapping functions remain separate from transport and routing so behavior is deterministic and testable.

**Tech Stack:** Python 3.12, FastAPI, Pydantic Settings, HTTPX, pytest, Ruff, Docker

**Execution note:** The user did not authorize Git commits. All commit steps are intentionally omitted.

---

## File structure

- `pyproject.toml`: package metadata, runtime and development dependencies, pytest and Ruff configuration.
- `app/config.py`: validated environment configuration and WeKnora API-prefix normalization.
- `app/models.py`: Dify and WeKnora wire models.
- `app/errors.py`: typed application errors.
- `app/auth.py`: constant-time Bearer credential verification.
- `app/mapping.py`: metadata-filter, request, and response transformations.
- `app/client.py`: async HTTPX transport and upstream error translation.
- `app/main.py`: application factory, lifecycle, routes, logging, and exception handlers.
- `tests/`: unit and HTTP-level tests.
- `Dockerfile`, `.dockerignore`, `.env.example`, `compose.example.yml`: deployment artifacts.
- `README.md`: setup, Dify integration, operations, and examples.

### Task 1: Package skeleton and settings

**Files:**
- Create: `pyproject.toml`
- Create: `app/__init__.py`
- Create: `app/config.py`
- Test: `tests/test_config.py`

- [ ] **Step 1: Write failing settings tests**

```python
def test_settings_normalizes_api_prefix():
    settings = Settings(
        weknora_base_url="https://kb.example/api/v1/",
        weknora_api_key="wk-secret",
        dify_adapter_api_key="adapter-secret",
    )
    assert settings.weknora_api_url == "https://kb.example/api/v1"


def test_settings_rejects_missing_required_secret(monkeypatch):
    monkeypatch.delenv("WEKNORA_API_KEY", raising=False)
    with pytest.raises(ValidationError):
        Settings()
```

- [ ] **Step 2: Run tests and verify the expected import failure**

Run: `pytest tests/test_config.py -q`

Expected: FAIL because `app.config` does not exist.

- [ ] **Step 3: Add package metadata and minimal settings implementation**

Implement a frozen `Settings` model with aliases for `WEKNORA_BASE_URL`, `WEKNORA_API_KEY`, `DIFY_ADAPTER_API_KEY`, `WEKNORA_TIMEOUT_SECONDS`, `LOG_LEVEL`, and `PORT`. Validate HTTP(S) URL, non-empty secrets, timeout range 1–120, port range 1–65535, and expose an `weknora_api_url` property that appends `/api/v1` only when missing.

- [ ] **Step 4: Run settings tests**

Run: `pytest tests/test_config.py -q`

Expected: all settings tests PASS.

### Task 2: Wire models and pure request mapping

**Files:**
- Create: `app/models.py`
- Create: `app/errors.py`
- Create: `app/mapping.py`
- Test: `tests/test_mapping.py`

- [ ] **Step 1: Write failing request-mapping tests**

Cover a valid no-filter request, `top_k` and threshold ranges, whitespace query rejection, knowledge document filters, tag filters, mismatched KB short-circuit, deduplication, unsupported `or`, unknown fields, unsupported comparison operators, and invalid condition value types.

The main expected mapping is:

```python
assert map_request(request).payload == {
    "query_text": "refund policy",
    "match_count": 5,
    "vector_threshold": 0.5,
    "disable_keywords_match": True,
    "disable_vector_match": False,
}
```

- [ ] **Step 2: Run mapping tests and verify failure**

Run: `pytest tests/test_mapping.py -q`

Expected: FAIL because mapping functions and models are missing.

- [ ] **Step 3: Implement models and request mapping**

Define strict Pydantic models for `RetrievalSetting`, `MetadataCondition`, `MetadataFilter`, `DifyRetrievalRequest`, `DifyRecord`, and `DifyRetrievalResponse`. Define a `MappedRequest` value containing `knowledge_base_id`, upstream `payload`, and `short_circuit_empty`.

Implement `map_request()` with these exact rules:

```python
payload = {
    "query_text": request.query.strip(),
    "match_count": request.retrieval_setting.top_k,
    "vector_threshold": request.retrieval_setting.score_threshold,
    "disable_keywords_match": True,
    "disable_vector_match": False,
}
```

Add deduplicated `knowledge_ids` and `tag_ids` only when present. Raise `AdapterError(400, "unsupported_metadata_condition", message)` for unsupported metadata expressions.

- [ ] **Step 4: Run mapping tests**

Run: `pytest tests/test_mapping.py -q`

Expected: all request-mapping tests PASS.

### Task 3: Response mapping

**Files:**
- Modify: `app/models.py`
- Modify: `app/mapping.py`
- Modify: `tests/test_mapping.py`

- [ ] **Step 1: Add failing response-mapping tests**

Cover valid records, empty results, title and filename fallback, `Untitled`, nested upstream metadata, threshold filtering, top-k truncation, score clamping, and skipping records with blank content, non-numeric score, NaN, or infinity.

Expected record example:

```python
assert response.records[0].model_dump() == {
    "content": "matched text",
    "score": 0.9,
    "title": "Guide",
    "metadata": {
        "knowledge_base_id": "kb-1",
        "knowledge_id": "doc-1",
        "chunk_id": "chunk-1",
        "chunk_index": 3,
        "source": "file",
        "filename": "guide.pdf",
        "weknora_metadata": {"page": "4"},
        "weknora_chunk_metadata": {},
    },
}
```

- [ ] **Step 2: Run the new tests and verify failure**

Run: `pytest tests/test_mapping.py -q`

Expected: FAIL because response mapping is absent.

- [ ] **Step 3: Implement response mapping**

Parse only a `success: true` envelope with a list-valued `data` field. Treat any other envelope as `AdapterError(502, "invalid_upstream_response", ...)`. Convert valid records, defensively filter by threshold, sort in upstream order, and truncate to `top_k`. Return skipped safe identifiers for structured logging without returning content.

- [ ] **Step 4: Run mapping tests**

Run: `pytest tests/test_mapping.py -q`

Expected: all mapping tests PASS.

### Task 4: WeKnora client and upstream errors

**Files:**
- Create: `app/client.py`
- Test: `tests/test_client.py`

- [ ] **Step 1: Write failing HTTPX transport tests**

Use `httpx.MockTransport` to verify URL escaping, `X-API-Key`, JSON payload, successful JSON parsing, 401/403 preservation, 5xx to 502 mapping, invalid JSON, timeout, and connection failures. Assert upstream bodies and secrets never appear in raised public messages.

- [ ] **Step 2: Run client tests and verify failure**

Run: `pytest tests/test_client.py -q`

Expected: FAIL because `WeKnoraClient` does not exist.

- [ ] **Step 3: Implement async WeKnora client**

Implement:

```python
async def hybrid_search(
    self, knowledge_base_id: str, payload: dict[str, object]
) -> dict[str, object]:
    path_id = quote(knowledge_base_id, safe="")
    response = await self._client.post(
        f"{self._api_url}/knowledge-bases/{path_id}/hybrid-search",
        headers={"X-API-Key": self._api_key},
        json=payload,
    )
```

Translate HTTPX timeout to 504, request errors to 502, 401/403 to their original status, and every other non-2xx response to 502. Parse JSON without exposing response bodies.

- [ ] **Step 4: Run client tests**

Run: `pytest tests/test_client.py -q`

Expected: all client tests PASS.

### Task 5: Authentication and FastAPI application

**Files:**
- Create: `app/auth.py`
- Create: `app/main.py`
- Test: `tests/test_api.py`

- [ ] **Step 1: Write failing endpoint tests**

Test `/healthz`, missing/malformed/incorrect credentials, successful retrieval, empty short-circuit without an upstream call, Pydantic validation errors using the stable error shape, metadata errors, and all upstream error mappings. Override settings and client dependencies so no real network calls occur.

- [ ] **Step 2: Run API tests and verify failure**

Run: `pytest tests/test_api.py -q`

Expected: FAIL because the application factory and routes are missing.

- [ ] **Step 3: Implement auth and app factory**

Use `HTTPBearer(auto_error=False)` and `secrets.compare_digest`. Add an application factory that accepts optional settings and HTTPX transport for tests, creates one shared `httpx.AsyncClient` in the FastAPI lifespan, and exposes:

```python
@app.get("/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/retrieval", response_model=DifyRetrievalResponse)
async def retrieval(request: DifyRetrievalRequest, _: None = Depends(authenticate)): ...
```

Add exception handlers that return `{"error_code": ..., "message": ...}` for application and request-validation failures. Add or propagate `X-Request-ID` without logging request bodies.

- [ ] **Step 4: Run API tests**

Run: `pytest tests/test_api.py -q`

Expected: all API tests PASS.

### Task 6: Logging safety and complete regression suite

**Files:**
- Modify: `app/main.py`
- Modify: `tests/test_api.py`
- Create: `tests/test_logging.py`

- [ ] **Step 1: Write failing logging-safety tests**

Capture logs during successful and failed retrievals. Assert logs include request ID, safe knowledge-base ID, status, and duration while excluding the adapter key, WeKnora key, full query, retrieved content, authorization header, and upstream response body.

- [ ] **Step 2: Run logging tests and verify failure**

Run: `pytest tests/test_logging.py -q`

Expected: FAIL until structured safe logging is implemented.

- [ ] **Step 3: Implement safe request logging**

Log JSON-compatible key/value fields only. Generate a UUID request ID when the incoming `X-Request-ID` is absent or unsafe. Log skipped upstream record identifiers without content.

- [ ] **Step 4: Run full tests**

Run: `pytest -q`

Expected: all tests PASS with no warnings.

### Task 7: Packaging and deployment artifacts

**Files:**
- Create: `.env.example`
- Create: `.dockerignore`
- Create: `Dockerfile`
- Create: `compose.example.yml`
- Create: `README.md`

- [ ] **Step 1: Add deployment files**

Use a `python:3.12-slim` image, install only the application package, create an unprivileged `adapter` user, expose port 8000, run Uvicorn, and configure a Python-based `/healthz` health check so curl is not required in the image.

The compose example must use environment-variable substitution and must not contain real secrets. It should connect to an existing WeKnora URL rather than bundling WeKnora or Dify.

- [ ] **Step 2: Add operational documentation**

Document environment variables, local and Docker startup, creation of a WeKnora `retrieve`-only and KB-restricted key, Dify External Knowledge API configuration, curl examples, metadata support, vector-only score semantics, error mappings, and security guidance.

- [ ] **Step 3: Run static checks**

Run: `ruff check .`

Expected: exit 0.

Run: `ruff format --check .`

Expected: exit 0.

- [ ] **Step 4: Build the package and container**

Run: `python -m build`

Expected: wheel and source distribution are created successfully.

Run: `docker build -t weknora-dify-adapter .`

Expected: image builds successfully and its configured user is non-root.

### Task 8: Final verification

**Files:**
- Verify all files against: `docs/superpowers/specs/2026-09-16-weknora-dify-adapter-design.md`

- [ ] **Step 1: Run the complete quality gate**

```bash
pytest -q
ruff check .
ruff format --check .
python -m build
docker build -t weknora-dify-adapter .
```

Expected: every command exits 0.

- [ ] **Step 2: Inspect the final tree and secrets**

Run: `rg -n "(wk-secret|adapter-secret|sk-[A-Za-z0-9])" . --glob '!docs/superpowers/**'`

Expected: only explicit test fixtures or documented placeholders, never deployable credentials.

- [ ] **Step 3: Re-read the design acceptance list**

Confirm every in-scope feature has a test or a directly verified deployment artifact. Report any unavailable verification, such as a missing local Docker daemon, as an explicit limitation rather than claiming it passed.
