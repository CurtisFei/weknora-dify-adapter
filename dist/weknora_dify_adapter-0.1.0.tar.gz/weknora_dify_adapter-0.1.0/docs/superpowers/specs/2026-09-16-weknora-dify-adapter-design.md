# WeKnora–Dify External Knowledge Adapter Design

## 1. Goal

Build a standalone Python service that exposes Dify's External Knowledge API and retrieves knowledge chunks from an existing WeKnora deployment. The adapter must not modify or fork WeKnora and must remain independently deployable and upgradeable.

The first release supports one WeKnora knowledge base per Dify external knowledge base. Dify's `knowledge_id` is treated as the WeKnora knowledge-base ID.

## 2. Technology and deployment

- Python 3.12
- FastAPI for HTTP routing, validation, OpenAPI, and Bearer authentication integration
- Pydantic Settings for environment-based configuration
- HTTPX for asynchronous calls to WeKnora
- pytest for unit and HTTP-level tests
- Ruff for formatting and static checks
- Docker image running as a non-root user

The adapter runs as a separate container or process beside Dify and WeKnora:

```text
Dify --POST /retrieval--> Adapter --POST hybrid-search--> WeKnora
```

## 3. Public API

### `POST /retrieval`

The endpoint implements the Dify External Knowledge API contract.

Required header:

```http
Authorization: Bearer <DIFY_ADAPTER_API_KEY>
```

Request body:

```json
{
  "knowledge_id": "weknora-kb-id",
  "query": "How does the refund process work?",
  "retrieval_setting": {
    "top_k": 5,
    "score_threshold": 0.5
  },
  "metadata_condition": {
    "logical_operator": "and",
    "conditions": []
  }
}
```

Successful response:

```json
{
  "records": [
    {
      "content": "Retrieved WeKnora chunk text",
      "score": 0.91,
      "title": "Source document title",
      "metadata": {
        "knowledge_base_id": "weknora-kb-id",
        "knowledge_id": "weknora-document-id",
        "chunk_id": "weknora-chunk-id",
        "chunk_index": 2,
        "source": "file",
        "filename": "guide.pdf"
      }
    }
  ]
}
```

No matching results return HTTP 200 and `{"records": []}`.

### `GET /healthz`

Returns HTTP 200 with `{"status":"ok"}`. It is a liveness endpoint and does not contact WeKnora. Upstream availability is instead visible through retrieval errors and structured logs, preventing a temporary WeKnora outage from continuously restarting the adapter.

## 4. Authentication and secrets

The adapter compares the incoming Bearer token with `DIFY_ADAPTER_API_KEY` using a constant-time comparison. Missing or invalid credentials return HTTP 401 with `WWW-Authenticate: Bearer`.

The adapter authenticates to WeKnora using `X-API-Key: <WEKNORA_API_KEY>`. The WeKnora key must have only the `retrieve` capability and should be restricted to the knowledge bases exposed through this adapter. The WeKnora key is never returned, logged, or forwarded from the caller.

## 5. Request mapping

The adapter calls:

```http
POST {WEKNORA_BASE_URL}/api/v1/knowledge-bases/{knowledge_id}/hybrid-search
X-API-Key: <WEKNORA_API_KEY>
Content-Type: application/json
```

The initial integration uses vector-only retrieval so that the returned score remains compatible with Dify's 0–1 similarity threshold:

```json
{
  "query_text": "<query>",
  "match_count": 5,
  "vector_threshold": 0.5,
  "disable_keywords_match": true,
  "disable_vector_match": false
}
```

Mapping rules:

- `knowledge_id` becomes the URL-escaped WeKnora knowledge-base ID.
- `query` becomes `query_text` after rejecting empty or whitespace-only input.
- `retrieval_setting.top_k` becomes `match_count` and must be from 1 through 100.
- `retrieval_setting.score_threshold` becomes `vector_threshold` and must be from 0 through 1.
- The adapter also filters returned records below `score_threshold` defensively and truncates them to `top_k`.

## 6. Metadata conditions

The first release supports a deliberately small subset instead of silently weakening a query.

Supported metadata names:

- `knowledge_base_id`: `is` only. The value must equal the request's `knowledge_id`; otherwise the request returns an empty result without calling WeKnora.
- `knowledge_id`: `is` or `in`. Values are mapped to WeKnora `knowledge_ids`.
- `tag_id` and `tag_ids`: `is` or `in`. Values are mapped to WeKnora `tag_ids`.

Supported logical operator:

- `and`

An empty condition list behaves as no filter. `or`, unknown field names, unsupported comparison operators, invalid value types, or conflicting `knowledge_id` conditions return HTTP 400 with a stable error code and a human-readable message. Conditions are deduplicated while preserving their first occurrence.

## 7. Response mapping

The adapter accepts WeKnora's `{"success":true,"data":[...]}` envelope. Each item maps as follows:

- `content` → `content`
- `score` → `score`, validated to be finite and clamped to the 0–1 range
- `knowledge_title` → `title`
- if `knowledge_title` is empty, `knowledge_filename` → `title`
- if both are empty, title becomes `Untitled`
- WeKnora identifiers and source fields are copied into a non-null metadata object
- existing WeKnora `metadata` and `chunk_metadata` are nested under namespaced keys to avoid overwriting adapter-owned metadata

Malformed result items lacking usable content or a numeric score are skipped and logged with identifiers but without document content. A syntactically invalid upstream envelope is treated as an upstream protocol error rather than as an empty result.

## 8. Error handling

The adapter returns JSON errors shaped as:

```json
{
  "error_code": "unsupported_metadata_condition",
  "message": "metadata field 'department' is not supported"
}
```

Mappings:

| Situation | HTTP status |
| --- | ---: |
| Missing or invalid adapter Bearer token | 401 |
| Invalid Dify request or unsupported metadata condition | 400 |
| WeKnora returns 401 | 401 |
| WeKnora returns 403 | 403 |
| WeKnora request times out | 504 |
| WeKnora connection failure, invalid JSON, invalid envelope, or other non-2xx response | 502 |
| Successful retrieval with no matches | 200 |

Upstream error bodies are not forwarded because they can contain deployment details. Logs include request IDs, status, duration, and safe identifiers, but never API keys, authorization headers, full queries, retrieved content, or upstream response bodies.

## 9. Configuration

Required environment variables:

- `WEKNORA_BASE_URL`
- `WEKNORA_API_KEY`
- `DIFY_ADAPTER_API_KEY`

Optional environment variables:

- `WEKNORA_TIMEOUT_SECONDS`, default `15`, allowed range 1–120
- `LOG_LEVEL`, default `INFO`
- `PORT`, default `8000`

Startup fails immediately if required configuration is missing or invalid. `WEKNORA_BASE_URL` is normalized by removing a trailing slash; it may include `/api/v1`, but the client must never append that prefix twice.

## 10. Components

- `app/main.py`: application factory, routes, exception handlers, and HTTPX client lifecycle.
- `app/config.py`: validated settings loaded from environment variables.
- `app/models.py`: Dify request/response models and WeKnora response models.
- `app/auth.py`: Bearer-token extraction and constant-time validation.
- `app/client.py`: URL construction and asynchronous WeKnora transport.
- `app/mapping.py`: pure request/filter/response transformations.
- `app/errors.py`: stable domain exceptions and HTTP status mapping.

Each component has a narrow interface so mapping logic can be tested without HTTP and upstream behavior can be tested with an in-process fake WeKnora server.

## 11. Testing and acceptance

Tests cover:

- health endpoint;
- missing, malformed, and incorrect Bearer credentials;
- required-field, range, and whitespace validation;
- request mapping, URL escaping, and `/api/v1` prefix normalization;
- empty results, title fallback, metadata namespacing, score filtering, and top-k truncation;
- each supported metadata filter and each unsupported condition class;
- upstream 401, 403, timeout, connection failure, 5xx, invalid JSON, and invalid envelopes;
- confirmation that secrets and content do not appear in logs;
- application startup with valid and invalid configuration.

Acceptance commands:

```bash
pytest
ruff check .
ruff format --check .
docker build -t weknora-dify-adapter .
```

The repository includes `.env.example`, `compose.example.yml`, a non-root `Dockerfile` with a health check, and a README containing local startup, Dify setup, WeKnora key permissions, curl examples, error behavior, and operational guidance.

## 12. Out of scope

- Modifying WeKnora or Dify source code
- Synchronizing or copying documents into Dify
- LLM-based answer generation
- Dify dataset management APIs
- Arbitrary metadata-expression evaluation
- Multi-knowledge-base fan-out for one Dify `knowledge_id`
- Caching, rate limiting, persistence, or an administrative UI
- Git commits, publishing images, or deploying to a live environment
